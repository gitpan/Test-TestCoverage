package TestCoverage::MyTestModule;

use strict;
use warnings;

sub test{
    return "Test\n";
}

sub methode{
    return "Methode\n";
}

1;